启动

npx http-server -e js -c-1 -p 9097